"""Smoke tests for inference helpers (no model needed). Run: python tests_smoke.py"""
import io
from PIL import Image
from src.inference import read_image, preprocess, InvalidImageError, load_class_names

def png(mode="RGB"):
    b = io.BytesIO(); Image.new(mode, (300, 200)).save(b, "PNG"); return b.getvalue()

assert read_image("a.png", png("L")).mode == "RGB"          # grayscale -> RGB
assert read_image("a.png", png("RGBA")).mode == "RGB"       # alpha -> RGB
assert preprocess(read_image("a.png", png())).shape == (1, 224, 224, 3)
assert len(load_class_names()) == 9
for name, data in [("a.gif", png()), ("a.png", b"not an image"), ("a.png", b"0" * (11 * 1024 * 1024))]:
    try: read_image(name, data); raise SystemExit(f"should reject {name}")
    except InvalidImageError: pass
print("All smoke tests passed")
