# Skin Cancer Classification - Final Report (Member 4 sections)

## 1. Problem statement & objective
Educational nine-class classification of dermoscopic skin-lesion images. Not a diagnostic system.

## 2. Dataset
Source: Kaggle "Skin Cancer: 9 classes (ISIC)". Image size 224x224. Test set: 118 images.
Class counts: <from Member 1>   Split method: <from Member 1>   Duplicate check: <see results/evaluation_metadata.json>

## 3. Methods
Baseline: EfficientNetB0, transfer learning + fine-tuning (hyperparameters: <Member 2>).
Improved: <model, imbalance method, hyperparameters: Member 3>.

## 4. Evaluation protocol
Same held-out test set for both models; test set not used for tuning. Seed/versions/date: see `evaluation_metadata.json`.
Command used: <paste from metadata>

## 5. Results
| Metric | Baseline | Improved | Change |
|---|---|---|---|
| Accuracy | 39.83% | <fill> | <pp> |
| Macro F1 | 0.3650 | <fill> | |
| Weighted F1 | 0.3628 | <fill> | |
| Test loss | 1.6992 | <fill> | |

Per-class table (with support) and confusion matrices: insert from `results/`.

## 6. Streamlit demo
Screenshots: upload, prediction + top-3 scores, invalid-file error, missing-model message.

## 7. Discussion
Weak classes, imbalance effects, small-test-set caveat (some classes n=3), leakage/duplicate caveats. Grad-CAM: <only if validated>.

## 8. Conclusion & future work
Based only on measured results; no clinical claims.
