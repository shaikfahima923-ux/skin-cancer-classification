# Skin Cancer Classification - Evaluation & Streamlit Demo (Member 4)

> **Educational project. Not a diagnostic tool.** No clinical reliability is claimed. Do not use for medical decisions.

Dataset: https://www.kaggle.com/datasets/nodoubttome/skin-cancer9-classesisic
Baseline: EfficientNetB0 (transfer learning + fine-tuning), branch `feature/baseline-model`, commit `c5a7b37`.
Recorded baseline: accuracy 39.83%, macro F1 0.3650, weighted F1 0.3628, test loss 1.6992 (118 test images).

## Structure
```
app.py                 Streamlit demo
src/inference.py       image validation, preprocessing, prediction
src/evaluate_models.py evaluation CLI (metrics, reports, confusion matrices, comparison CSV)
notebooks/01_evaluate_models_kaggle.ipynb   run evaluation on Kaggle
notebooks/02_streamlit_demo_kaggle.ipynb    run the demo on Kaggle (public tunnel)
models/class_names.json  class order (MUST match training - confirm with Members 1-3)
results/                 metrics, reports, confusion matrices, model_comparison.csv
tests_smoke.py           input-handling smoke tests (no model needed)
```

## Model artifacts
`*.keras` files are git-ignored. Obtain `baseline.keras` (Member 2) and `improved.keras` (Member 3), upload them as a **private Kaggle Dataset**, and place a copy in `models/` for the app. Do not commit weights without team approval.

## Run evaluation (Kaggle - no local compute)
1. kaggle.com -> New Notebook -> File -> Import notebook -> `notebooks/01_evaluate_models_kaggle.ipynb`.
2. Add inputs: the ISIC dataset + your models dataset. GPU optional, Internet not needed.
3. Edit the `MODELS` dict if filenames differ, then Run All.
4. Download `results.zip` from the Output tab and copy its files into `results/`.

## Run the app
- On Kaggle: `notebooks/02_streamlit_demo_kaggle.ipynb` (Internet ON) prints a temporary public link.
- Anywhere with Python: `pip install -r requirements.txt && python -m streamlit run app.py`

## Smoke test
`python tests_smoke.py` (valid RGB/grayscale/RGBA, wrong type, corrupt and oversized files).

## Protocol notes
- Test set used only for final evaluation; class order fixed by `models/class_names.json`.
- No extra normalisation (EfficientNet rescales internally); no augmentation at inference.
- The 118-image test set has very small classes (some have 3 images): interpret per-class scores cautiously.
- Uploaded images are not stored.

## Limitations
Low accuracy (baseline ~40%), class imbalance, tiny test set, possible duplicate/leakage caveats (see `evaluation_metadata.json`), dermoscopy-only training data, no clinical validation. Grad-CAM is not included until Member 3 supplies a tested implementation and target layer.

## Git
```
git switch -c feature/evaluation-streamlit   # check the name is free and agreed first
git add app.py src README.md requirements.txt tests_smoke.py notebooks results/model_comparison.csv models/class_names.json .gitignore
git diff --cached
git commit -m "Add model evaluation and Streamlit demo"
git push -u origin feature/evaluation-streamlit
```
Open a PR; do not merge to `main` without team review.
