"""Streamlit demo: experimental nine-class skin-lesion image classifier (educational only)."""
from pathlib import Path

import streamlit as st

from src.inference import (InvalidImageError, ModelMissingError, load_class_names, load_model,
                           predict, read_image)

st.set_page_config(page_title="Skin Lesion Classifier (Demo)", page_icon="🔬")
st.title("Skin Lesion Image Classification - Experimental Demo")
st.write("An educational nine-class image-classification demo (ISIC data, EfficientNetB0 transfer learning).")
st.error("**Not medical advice or a diagnosis.** This model is experimental and has low accuracy. "
         "Do not use it to make health decisions. See a qualified clinician for any skin concern.")

MODEL_DIR = Path("models")
available = sorted(p.name for p in MODEL_DIR.glob("*.keras")) if MODEL_DIR.exists() else []
if not available:
    st.warning("No model file found in `models/`. Place `baseline.keras` / `improved.keras` there "
               "(see README, 'Model artifacts').")
    st.stop()

choice = st.selectbox("Model", available)
class_names = load_class_names()


@st.cache_resource(show_spinner="Loading model...")
def get_model(name):
    return load_model(MODEL_DIR / name)


try:
    model = get_model(choice)
except ModelMissingError as e:
    st.error(str(e)); st.stop()
except Exception:
    st.error("The model could not be loaded. Check that the file and TensorFlow version are compatible.")
    st.stop()

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0
up = st.file_uploader("Upload a JPG, JPEG or PNG image", type=["jpg", "jpeg", "png"],
                      key=f"up{st.session_state.uploader_key}")

if up is not None:
    try:
        img = read_image(up.name, up.getvalue())
    except InvalidImageError as e:
        st.error(str(e)); st.stop()
    st.image(img, caption="Uploaded image (not stored)", use_container_width=True)
    try:
        top = predict(model, img, class_names, top_k=3)
    except ValueError as e:
        st.error(str(e)); st.stop()
    st.subheader(f"Predicted class: {top[0][0]}")
    st.caption("Scores are raw model outputs, not diagnostic certainty.")
    for name, p in top:
        st.write(f"{name}: {p:.1%}"); st.progress(min(max(p, 0.0), 1.0))
    if st.button("Upload another image"):
        st.session_state.uploader_key += 1; st.rerun()
