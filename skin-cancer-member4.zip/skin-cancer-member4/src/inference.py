"""Shared inference helpers used by the Streamlit app."""
import io, json
from pathlib import Path

import numpy as np
from PIL import Image, UnidentifiedImageError

ALLOWED_EXT = {".jpg", ".jpeg", ".png"}
MAX_BYTES = 10 * 1024 * 1024
IMG_SIZE = 224  # baseline EfficientNetB0 input; confirm for the improved model
DEFAULT_CLASSES = ["actinic keratosis", "basal cell carcinoma", "dermatofibroma", "melanoma",
                   "nevus", "pigmented benign keratosis", "seborrheic keratosis",
                   "squamous cell carcinoma", "vascular lesion"]


class ModelMissingError(Exception):
    pass


class InvalidImageError(Exception):
    pass


def load_class_names(path="models/class_names.json"):
    p = Path(path)
    return json.load(open(p)) if p.exists() else DEFAULT_CLASSES


def load_model(model_path):
    p = Path(model_path)
    if not p.exists():
        raise ModelMissingError(f"Model file not found: {p.name}. See README 'Model artifacts'.")
    import tensorflow as tf
    return tf.keras.models.load_model(p, compile=False)


def read_image(uploaded_name, data: bytes):
    if Path(uploaded_name).suffix.lower() not in ALLOWED_EXT:
        raise InvalidImageError("Unsupported file type. Please upload a JPG, JPEG or PNG.")
    if len(data) > MAX_BYTES:
        raise InvalidImageError("File is larger than 10 MB.")
    try:
        Image.open(io.BytesIO(data)).verify()
        return Image.open(io.BytesIO(data)).convert("RGB")  # handles grayscale / RGBA / palette
    except (UnidentifiedImageError, OSError, ValueError, SyntaxError):
        raise InvalidImageError("The file could not be read as an image (it may be corrupted).")


def preprocess(img: Image.Image, size=IMG_SIZE):
    # No extra normalisation: Keras EfficientNet has its own rescaling layer inside the model.
    # No augmentation at inference time.
    arr = np.asarray(img.resize((size, size), Image.BILINEAR), dtype="float32")
    return arr[None, ...]


def predict(model, img, class_names, top_k=3, size=IMG_SIZE):
    probs = model.predict(preprocess(img, size), verbose=0)[0]
    if probs.shape[0] != len(class_names):
        raise ValueError(f"Model outputs {probs.shape[0]} scores but {len(class_names)} class names are set.")
    if not np.isclose(probs.sum(), 1.0, atol=1e-3):
        e = np.exp(probs - probs.max()); probs = e / e.sum()
    idx = np.argsort(probs)[::-1][:top_k]
    return [(class_names[i], float(probs[i])) for i in idx]
