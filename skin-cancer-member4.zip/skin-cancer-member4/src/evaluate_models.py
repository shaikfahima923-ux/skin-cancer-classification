"""Evaluate one or more Keras models on the SAME held-out test set.

Usage (Kaggle or local):
  python src/evaluate_models.py \
      --test-dir "/kaggle/input/<dataset>/.../Test" \
      --train-dir "/kaggle/input/<dataset>/.../Train" \
      --model baseline=/kaggle/input/<models>/baseline.keras \
      --model improved=/kaggle/input/<models>/improved.keras \
      --class-names models/class_names.json --out results

Never tune anything against these results: the test set is for final evaluation only.
"""
import argparse, datetime, hashlib, json, platform, sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.metrics import (accuracy_score, balanced_accuracy_score, classification_report,
                             confusion_matrix, f1_score, log_loss)

IMG_EXT = {".jpg", ".jpeg", ".png"}


def md5(path, chunk=1 << 20):
    h = hashlib.md5()
    with open(path, "rb") as f:
        while b := f.read(chunk):
            h.update(b)
    return h.hexdigest()


def duplicate_check(train_dir, test_dir):
    """Exact byte-duplicate check between Train and Test (leakage guard)."""
    tr = {md5(p): p for p in Path(train_dir).rglob("*") if p.suffix.lower() in IMG_EXT}
    dups = [p.name for p in Path(test_dir).rglob("*")
            if p.suffix.lower() in IMG_EXT and md5(p) in tr]
    return {"train_images": len(tr), "exact_duplicates_in_test": len(dups), "examples": dups[:10]}


def load_test_ds(test_dir, class_names, img_size, batch_size):
    import tensorflow as tf
    ds = tf.keras.utils.image_dataset_from_directory(
        test_dir, labels="inferred", label_mode="int", class_names=class_names,
        image_size=(img_size, img_size), batch_size=batch_size, shuffle=False,
        color_mode="rgb")
    y = np.concatenate([lab.numpy() for _, lab in ds])
    return ds, y


def predict_probs(model, ds):
    probs = model.predict(ds, verbose=0)
    # If the model outputs logits (rows don't sum to 1), apply softmax.
    if not np.allclose(probs.sum(axis=1), 1.0, atol=1e-3):
        e = np.exp(probs - probs.max(axis=1, keepdims=True))
        probs = e / e.sum(axis=1, keepdims=True)
    return probs


def save_confusion(cm, class_names, title, path):
    fig, ax = plt.subplots(figsize=(9, 8))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(class_names))); ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=45, ha="right"); ax.set_yticklabels(class_names)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True"); ax.set_title(title)
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, int(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > cm.max() / 2 else "black", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046); fig.tight_layout()
    fig.savefig(path, dpi=150); plt.close(fig)


def evaluate(name, model_path, ds, y_true, class_names, out):
    import tensorflow as tf
    model = tf.keras.models.load_model(model_path, compile=False)
    n_out = model.output_shape[-1]
    assert n_out == len(class_names), f"{name}: model has {n_out} outputs, expected {len(class_names)}"
    probs = predict_probs(model, ds)
    y_pred = probs.argmax(1)
    labels = list(range(len(class_names)))
    m = {
        "model": name, "model_file": Path(model_path).name,
        "accuracy": accuracy_score(y_true, y_pred),
        "test_loss": log_loss(y_true, np.clip(probs, 1e-7, 1), labels=labels),
        "macro_f1": f1_score(y_true, y_pred, average="macro", zero_division=0),
        "weighted_f1": f1_score(y_true, y_pred, average="weighted", zero_division=0),
        "balanced_accuracy": balanced_accuracy_score(y_true, y_pred),
        "n_test_images": int(len(y_true)),
    }
    rep = classification_report(y_true, y_pred, labels=labels, target_names=class_names,
                                output_dict=True, zero_division=0)
    pd.DataFrame(rep).T.to_csv(out / f"{name}_classification_report.csv")
    cm = confusion_matrix(y_true, y_pred, labels=labels)
    pd.DataFrame(cm, index=class_names, columns=class_names).to_csv(out / f"{name}_confusion_matrix.csv")
    save_confusion(cm, class_names, f"{name} - confusion matrix (n={len(y_true)})",
                   out / f"{name}_confusion_matrix.png")
    with open(out / f"{name}_metrics.json", "w") as f:
        json.dump(m, f, indent=2)
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-dir", required=True)
    ap.add_argument("--train-dir", default=None, help="optional: enables exact-duplicate leakage check")
    ap.add_argument("--model", action="append", required=True, help="name=path (repeat; first = baseline)")
    ap.add_argument("--class-names", default=None, help="JSON list; default = sorted test sub-folder names")
    ap.add_argument("--img-size", type=int, default=224)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", default="results")
    a = ap.parse_args()

    import tensorflow as tf
    tf.keras.utils.set_random_seed(a.seed)
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)

    folders = sorted(p.name for p in Path(a.test_dir).iterdir() if p.is_dir())
    if a.class_names and Path(a.class_names).exists():
        class_names = json.load(open(a.class_names))
    else:
        class_names = folders
    assert sorted(class_names) == folders, f"class names {class_names} != test folders {folders}"
    print("Class order:", dict(enumerate(class_names)))

    meta = {"date": datetime.datetime.now().isoformat(timespec="seconds"),
            "command": " ".join(sys.argv), "python": platform.python_version(),
            "tensorflow": tf.__version__, "numpy": np.__version__, "seed": a.seed,
            "img_size": a.img_size, "class_names": class_names}
    if a.train_dir:
        meta["duplicate_check"] = duplicate_check(a.train_dir, a.test_dir)
        print("Duplicate check:", meta["duplicate_check"])

    ds, y_true = load_test_ds(a.test_dir, class_names, a.img_size, a.batch_size)
    support = pd.Series(y_true).value_counts().sort_index()
    meta["support"] = {class_names[i]: int(c) for i, c in support.items()}
    print("Support:", meta["support"])

    results = []
    for spec in a.model:
        name, path = spec.split("=", 1)
        print(f"\n=== Evaluating {name}: {path}")
        results.append(evaluate(name, path, ds, y_true, class_names, out))

    keys = [("accuracy", "Accuracy"), ("macro_f1", "Macro F1"), ("weighted_f1", "Weighted F1"),
            ("test_loss", "Test loss"), ("balanced_accuracy", "Balanced accuracy")]
    rows = []
    for k, label in keys:
        row = {"Metric": label}
        for r in results:
            row[r["model"]] = round(r[k], 4)
        if len(results) >= 2:
            row["Change (last - first)"] = round(results[-1][k] - results[0][k], 4)
        rows.append(row)
    cmp = pd.DataFrame(rows)
    cmp.to_csv(out / "model_comparison.csv", index=False)
    meta["note"] = "Accuracy is a fraction; multiply by 100 for percent / percentage points."
    with open(out / "evaluation_metadata.json", "w") as f:
        json.dump(meta, f, indent=2)
    print("\n", cmp.to_string(index=False))
    print("\nSaved to", out.resolve())


if __name__ == "__main__":
    main()
